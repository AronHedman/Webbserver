<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docker LEMP</title>
</head>
<body>
    <h1>Docker LEMP</h1>
    <?php
      phpinfo();
    ?>
</body>
</html>